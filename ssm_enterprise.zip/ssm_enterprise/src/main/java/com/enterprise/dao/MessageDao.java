package com.enterprise.dao;


import com.enterprise.entity.Messages;

public interface MessageDao extends DaoManage<Messages>{

}
