package com.enterprise.dao;


import com.enterprise.entity.Recruitment;

public interface RecruitmentDao extends DaoManage<Recruitment>{

}
