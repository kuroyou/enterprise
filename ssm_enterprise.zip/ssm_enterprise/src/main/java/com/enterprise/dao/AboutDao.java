package com.enterprise.dao;

import com.enterprise.entity.About;

/**
 *
 * Created by admin on 2020/7/8.
 */
public interface AboutDao extends DaoManage<About>{
}
