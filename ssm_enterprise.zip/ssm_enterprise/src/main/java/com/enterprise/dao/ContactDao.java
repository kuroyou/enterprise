package com.enterprise.dao;


import com.enterprise.entity.Contact;

/**
 * Created by admin on 2020/7/8.
 */
public interface ContactDao extends DaoManage<Contact>{
}
