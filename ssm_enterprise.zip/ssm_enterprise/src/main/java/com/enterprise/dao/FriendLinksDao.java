package com.enterprise.dao;


import com.enterprise.entity.FriendLinks;

public interface FriendLinksDao extends DaoManage<FriendLinks>{



}
