package com.enterprise.dao;


import com.enterprise.entity.IndexImg;

/**
 * Created by admin on 2020/5/27.
 */
public interface IndexImgDao extends DaoManage<IndexImg>{
}
