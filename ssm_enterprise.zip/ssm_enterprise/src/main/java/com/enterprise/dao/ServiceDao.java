package com.enterprise.dao;


import com.enterprise.entity.Service;

/**
 * Created by admin on 2020/6/14.
 */
public interface ServiceDao extends DaoManage<Service>{
}
