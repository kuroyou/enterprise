package com.enterprise.service;


import com.enterprise.entity.Recruitment;

public interface RecruitmentService extends Services<Recruitment>{

}
