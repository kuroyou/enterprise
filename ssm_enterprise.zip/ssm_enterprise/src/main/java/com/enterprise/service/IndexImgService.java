package com.enterprise.service;

import com.enterprise.entity.IndexImg;

/**
 * Created by admin on 2020/5/27.
 */
public interface IndexImgService extends Services<IndexImg>{
}
