package com.enterprise.service;

import com.enterprise.entity.About;

/**
 * Created by admin on 2020/7/8.
 */
public interface AboutService extends Services<About>{
}
