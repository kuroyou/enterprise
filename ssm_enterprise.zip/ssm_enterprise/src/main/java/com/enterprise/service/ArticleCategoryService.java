package com.enterprise.service;

import com.enterprise.entity.ArticleCategory;

/**
 * Created by admin on 2020/6/14.
 */
public interface ArticleCategoryService extends Services<ArticleCategory>{
}
