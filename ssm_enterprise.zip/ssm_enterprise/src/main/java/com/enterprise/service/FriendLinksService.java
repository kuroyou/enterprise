package com.enterprise.service;

import com.enterprise.entity.FriendLinks;

public interface FriendLinksService extends Services<FriendLinks>{



}
