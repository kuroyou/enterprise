package com.enterprise.service;

import com.enterprise.entity.Messages;

public interface MessageService extends Services<Messages>{

}
