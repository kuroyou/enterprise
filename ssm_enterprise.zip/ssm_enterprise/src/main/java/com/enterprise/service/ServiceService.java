package com.enterprise.service;

import com.enterprise.entity.Service;

/**
 * Created by admin on 2020/6/14.
 */
public interface ServiceService extends Services<Service>{
}
