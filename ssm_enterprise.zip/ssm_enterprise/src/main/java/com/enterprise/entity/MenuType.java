package com.enterprise.entity;

/**
 * 菜单属性枚举类
 */
public enum MenuType {

	module,
	page,
	button
	
}
