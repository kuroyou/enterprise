package com.enterprise.entity.page;

public interface CleanBean {
	void clean();

}
